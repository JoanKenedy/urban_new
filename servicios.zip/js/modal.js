// const modal = document.getElementById("modalPromo");
// const cerrar = document.getElementById("modalPromo");

// window.addEventListener("load", function (event) {
//   const time = setTimeout(myModal, 2000);
// });

// function myModal() {
//   const close = document.getElementById("close");
//   modal.classList.add("modal-show");

//   close.addEventListener("click", () => {
//     modal.classList.remove("modal-show");
//   });
//   cerrar.addEventListener("click", () => {
//     modal.classList.remove("modal-show");
//   });
// }
